import { type ClassValue, clsx } from "clsx"
import { extendTailwindMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return extendTailwindMerge({
    extend: {
      classGroups: {
      },
      conflictingClassGroupModifiers: {},
    },
  })(clsx(inputs))
}
