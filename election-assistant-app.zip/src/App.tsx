import { useState, useRef, useEffect } from "react";
import Markdown from "react-markdown";
import { Send, Bot, User, Menu } from "lucide-react";
import { generateChatResponse } from "./services/geminiService";
import electionData from "./data.json";
import { cn } from "./lib/utils";

type Message = {
  id: string;
  role: "user" | "model";
  content: string;
};

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "model",
      content: "Hi! I'm your Civic Guide. I can help answer questions about the voting process. Are you registered to vote?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // Eligibility Quiz State
  const [quizState, setQuizState] = useState<string | null>(null);
  const [quizResult, setQuizResult] = useState<string | null>(null);

  // Polling Station Search State
  const [zipCode, setZipCode] = useState("");
  const [zipResult, setZipResult] = useState<string | null>(null);
  const [isSearchingZip, setIsSearchingZip] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput("");
    
    // Add user message
    const newUserMsg: Message = { id: Date.now().toString(), role: "user", content: userMessage };
    setMessages((prev) => [...prev, newUserMsg]);
    setIsLoading(true);

    try {
      // Format history for Gemini API
      const chatHistory = messages.map(msg => ({
          role: msg.role,
          parts: [{text: msg.content}]
      }));

      const botResponse = await generateChatResponse(userMessage, chatHistory);

      setMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: "model", content: botResponse },
      ]);
    } catch (error) {
      console.error(error);
      setMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: "model", content: "Oops, something went wrong. Let's try that again." },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const currentQuestion = quizState ? electionData.questions.find(q => q.id === quizState) : null;

  const startQuiz = () => {
    setQuizState("q1");
    setQuizResult(null);
    setSidebarOpen(false); // Close sidebar on mobile
  };

  const handleQuizAnswer = (nextId: string) => {
    if (electionData.results[nextId as keyof typeof electionData.results]) {
      // It's a result
      setQuizState(null);
      setQuizResult(electionData.results[nextId as keyof typeof electionData.results]);
    } else {
      // It's the next question
      setQuizState(nextId);
    }
  };

  const handleZipCodeSubmit = async () => {
    if (!zipCode.trim() || isSearchingZip) return;
    setIsSearchingZip(true);
    setZipResult(null);
    try {
      const response = await generateChatResponse(
        `What are the upcoming local election dates and general polling station information for the US ZIP code ${zipCode}? Provide a brief answer (max 3 sentences) and a suggestion on where to find the exact polling location online.`, 
        [] // empty history for this specific isolated query
      );
      setZipResult(response);
    } catch (error) {
      setZipResult("Sorry, couldn't fetch details for that ZIP code at the moment. Please visit vote.org for more information.");
    } finally {
      setIsSearchingZip(false);
    }
  };

  return (
    <div className="flex h-screen w-full font-sans overflow-hidden bg-transparent text-slate-100">
      <div className="particles-bg"></div>
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden transition-opacity"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed md:static inset-y-0 left-0 z-50 w-80 glass-panel border-r border-white/10 transform transition-transform duration-500 ease-in-out flex flex-col h-full",
        sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}>
        <div className="p-6 border-b border-white/5 flex-shrink-0 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/20 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 flex items-center gap-3">
            <span role="img" aria-label="ballot box" className="text-2xl drop-shadow-lg">🗳️</span>
            Civic Guide
          </h1>
          <p className="text-sm text-slate-400 mt-1">Election Process AI</p>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-10 custom-scrollbar">
          
          {/* Quick Links / Actions */}
          <section>
             <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                <span className="w-4 h-px bg-slate-600"></span> Quick Actions <span className="w-full h-px bg-slate-800/50"></span>
             </h2>
             <div className="space-y-3">
                 <button 
                    onClick={startQuiz}
                    className="w-full text-left bg-gradient-to-r from-blue-600/10 to-purple-600/10 hover:from-blue-600/20 hover:to-purple-600/20 border border-blue-500/20 px-4 py-3.5 rounded-xl text-sm font-medium transition-all duration-300 group relative overflow-hidden"
                 >
                    <div className="absolute inset-0 w-1/4 h-full bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-[400%] transition-transform duration-1000 ease-in-out"></div>
                    <span className="text-blue-300 flex items-center gap-2">
                       <span className="bg-blue-500/20 p-1.5 rounded-md text-blue-400 font-bold">Q</span>
                       Am I eligible to vote? (Quiz)
                    </span>
                 </button>
                 <button 
                    onClick={() => {
                        const question = "How does the candidate nomination process work and what are the eligibility criteria?";
                        setSidebarOpen(false);
                        const newUserMsg: Message = { id: Date.now().toString(), role: "user", content: question };
                        setMessages((prev) => [...prev, newUserMsg]);
                        setIsLoading(true);
                        
                        generateChatResponse(question, messages.map(msg => ({ role: msg.role, parts: [{text: msg.content}] })))
                          .then(botResponse => {
                             setMessages((prev) => [...prev, { id: (Date.now() + 1).toString(), role: "model", content: botResponse }]);
                          })
                          .catch(() => {
                             setMessages((prev) => [...prev, { id: (Date.now() + 1).toString(), role: "model", content: "Oops, something went wrong. Let's try that again." }]);
                          })
                          .finally(() => setIsLoading(false));
                    }}
                    className="w-full text-left glass-card hover:bg-white/5 border border-white/5 px-4 py-3.5 rounded-xl text-sm font-medium transition-all duration-300 text-slate-300"
                 >
                    <span className="flex items-center gap-2">
                       <span className="bg-slate-700/50 p-1.5 rounded-md text-slate-300">📋</span>
                       Candidate Nomination
                    </span>
                 </button>
             </div>
          </section>

          {/* Timeline Tracker */}
          <section>
            <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
               <span className="w-4 h-px bg-slate-600"></span> Election Timeline <span className="w-full h-px bg-slate-800/50"></span>
            </h2>
            <div className="space-y-6">
              <div className="space-y-5 relative ml-2">
                {electionData.timeline.map((item, idx) => (
                  <div key={idx} className="relative flex gap-5 group">
                     <div className="flex flex-col items-center">
                        <div className={cn(
                          "w-3.5 h-3.5 rounded-full mt-1 shrink-0 z-10 transition-all duration-500",
                          item.status === 'completed' ? "bg-purple-500 shadow-[0_0_10px_purple] ring-4 ring-purple-900/40" :
                          item.status === 'active' ? "bg-blue-400 shadow-[0_0_12px_#60a5fa] ring-4 ring-blue-900/50" : "bg-slate-700 border-2 border-slate-600"
                        )} />
                        {idx !== electionData.timeline.length - 1 && (
                          <div className={cn(
                             "w-px h-full mt-1.5 absolute top-3 bottom-0 left-[7px] -translate-x-1/2 transition-colors duration-500",
                             item.status === 'completed' ? "bg-gradient-to-b from-purple-500 to-blue-500/50" :
                             item.status === 'active' ? "bg-gradient-to-b from-blue-500 to-slate-700" : "bg-slate-700/50"
                          )} />
                        )}
                     </div>
                     <div className="pb-1 transition-transform duration-300 group-hover:translate-x-1">
                        <div className={cn(
                          "font-semibold text-sm",
                          item.status === 'completed' ? "text-slate-300" :
                          item.status === 'active' ? "text-blue-300" : "text-slate-500"
                        )}>{item.phase}</div>
                        <div className="text-xs text-slate-400 mt-1 leading-relaxed">{item.description}</div>
                     </div>
                  </div>
                ))}
              </div>

              {/* Local Info Search */}
              <div className="glass-card rounded-xl p-4 mt-8 relative overflow-hidden">
                <div className="absolute -top-10 -right-10 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl"></div>
                <h3 className="text-sm font-semibold text-slate-200 mb-2">Find Local Info</h3>
                <p className="text-[11px] text-slate-400 mb-4 leading-relaxed">Enter your ZIP code to find your polling station and local election dates.</p>
                <div className="flex gap-2 relative z-10">
                  <input
                    type="text"
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                    placeholder="ZIP Code..."
                    className="flex-1 w-full bg-slate-900/50 border border-slate-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all text-slate-200 placeholder-slate-500 shadow-inner"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleZipCodeSubmit();
                      }
                    }}
                  />
                  <button
                    onClick={handleZipCodeSubmit}
                    disabled={!zipCode.trim() || isSearchingZip}
                    className="bg-blue-600 hover:bg-blue-500 border border-blue-400/30 text-white rounded-lg px-4 py-2.5 text-sm font-medium disabled:opacity-50 transition-all shadow-[0_0_15px_rgba(37,99,235,0.3)] flex items-center justify-center min-w-[70px]"
                  >
                    {isSearchingZip ? (
                       <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                       "Find"
                    )}
                  </button>
                </div>
                {zipResult && (
                  <div className="mt-4 text-xs text-slate-300 bg-slate-900/60 p-3.5 rounded-lg border border-slate-700/50 markdown-body shadow-inner">
                    <Markdown>{zipResult}</Markdown>
                  </div>
                )}
              </div>
            </div>
          </section>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col h-full relative min-w-0 z-10">
        
        {/* Header */}
        <header className="h-16 glass-panel border-b border-white/5 border-t-0 border-l-0 border-r-0 flex items-center px-4 md:px-8 flex-shrink-0 z-20 sticky top-0 backdrop-blur-md">
          <button 
            className="md:hidden p-2.5 text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-lg mr-3 transition-colors"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1">
             <h2 className="font-semibold text-slate-200 tracking-wide">Voting Assistant</h2>
             <p className="text-xs text-blue-400 font-medium">Process Education</p>
          </div>
        </header>

        {/* Chat / Quiz Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-32 custom-scrollbar">
          <div className="max-w-3xl mx-auto w-full space-y-8">
            
            {/* Quiz Overlay / Display */}
            {(quizState || quizResult) && (
              <div className="mb-8 p-8 glass-panel rounded-2xl relative overflow-hidden border border-blue-500/20 shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
                <div className="absolute top-0 left-0 w-1.5 bg-gradient-to-b from-blue-500 to-purple-500 h-full" />
                <div className="absolute -top-20 -right-20 w-40 h-40 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
                
                <button 
                  onClick={() => { setQuizState(null); setQuizResult(null); }}
                  className="absolute top-5 right-5 text-slate-500 hover:text-slate-300 text-sm font-medium transition-colors bg-slate-800/50 px-3 py-1 rounded-full border border-white/5"
                >
                  Close Quiz
                </button>
                
                {quizState && currentQuestion && (
                  <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 mt-2 relative z-10">
                    <div className="flex items-center gap-2 mb-4">
                       <span className="px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-400 text-[10px] font-bold tracking-wider uppercase border border-blue-500/30">Quiz Mode</span>
                    </div>
                    <p className="text-xl md:text-2xl font-medium text-slate-100 mb-8 leading-snug">{currentQuestion.text}</p>
                    <div className="flex flex-wrap gap-4">
                       {currentQuestion.options.map((opt, i) => (
                         <button
                           key={i}
                           onClick={() => handleQuizAnswer(opt.nextId)}
                           className="bg-slate-800 hover:bg-blue-600 border border-slate-600 hover:border-blue-400 text-slate-200 hover:text-white px-6 py-3 rounded-xl text-sm font-semibold transition-all duration-300 shadow-md hover:shadow-[0_0_20px_rgba(37,99,235,0.4)]"
                         >
                           {opt.value}
                         </button>
                       ))}
                    </div>
                  </div>
                )}

                {quizResult && (
                  <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 mt-2 relative z-10">
                     <div className="flex items-center gap-2 mb-4">
                       <span className="px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-400 text-[10px] font-bold tracking-wider uppercase border border-purple-500/30">Quiz Result</span>
                     </div>
                     <p className="text-lg md:text-xl text-slate-200 leading-relaxed font-medium">{quizResult}</p>
                  </div>
                )}
              </div>
            )}

            {/* Messages */}
            {!quizState && !quizResult && messages.map((msg, index) => (
              <div
                key={msg.id}
                className={cn(
                  "flex gap-4 md:gap-5 group",
                  msg.role === "user" ? "justify-end" : "justify-start animate-in fade-in slide-in-from-bottom-4 duration-500"
                )}
                style={{ animationFillMode: 'both', animationDelay: `${index === messages.length - 1 && msg.role === 'model' ? 100 : 0}ms` }}
              >
                {msg.role === "model" && (
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shrink-0 mt-1 shadow-[0_0_15px_rgba(59,130,246,0.3)] border border-white/10">
                    <Bot className="w-5 h-5 text-white drop-shadow-md" />
                  </div>
                )}
                
                <div
                  className={cn(
                    "max-w-[85%] md:max-w-[80%] rounded-2xl px-6 py-4 relative shadow-lg",
                    msg.role === "user"
                      ? "bg-gradient-to-br from-blue-600 to-indigo-600 text-white rounded-tr-sm border border-blue-400/20"
                      : "glass-panel text-slate-200 rounded-tl-sm"
                  )}
                >
                  {msg.role === "user" ? (
                    <div className="whitespace-pre-wrap leading-relaxed">{msg.content}</div>
                  ) : (
                    <div className="markdown-body text-[15px] md:text-base leading-relaxed tracking-wide">
                       <Markdown>{msg.content}</Markdown>
                    </div>
                  )}
                </div>

                {msg.role === "user" && (
                  <div className="w-9 h-9 rounded-xl bg-slate-700/80 flex items-center justify-center shrink-0 mt-1 border border-white/10">
                    <User className="w-5 h-5 text-slate-300" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
               <div className="flex gap-5 animate-in fade-in duration-300">
                 <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shrink-0 mt-1 shadow-[0_0_15px_rgba(59,130,246,0.3)]">
                    <Bot className="w-5 h-5 text-white" />
                 </div>
                 <div className="glass-panel rounded-2xl rounded-tl-sm px-6 py-5 shadow-lg flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-blue-400 animate-pulse" style={{ animationDelay: '0ms', animationDuration: '1s' }} />
                    <div className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-pulse" style={{ animationDelay: '200ms', animationDuration: '1s' }} />
                    <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" style={{ animationDelay: '400ms', animationDuration: '1s' }} />
                 </div>
               </div>
            )}
            <div ref={messagesEndRef} className="h-10" />
          </div>
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-[#0f172a] via-[#0f172a]/95 to-transparent pt-12 z-20 pointer-events-none">
          <div className="max-w-3xl mx-auto w-full relative pointer-events-auto">
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl blur opacity-30 group-focus-within:opacity-60 transition duration-500"></div>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Ask about the voting process..."
                className="relative w-full bg-slate-900/90 backdrop-blur-xl border border-white/10 rounded-2xl pl-6 pr-16 py-4 focus:outline-none focus:border-blue-400/50 resize-none text-base min-h-[60px] max-h-[200px] text-white shadow-xl placeholder-slate-500 transition-colors"
                rows={1}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="absolute right-3 bottom-2.5 p-2.5 bg-gradient-neon text-white rounded-xl hover:shadow-[0_0_20px_rgba(168,85,247,0.4)] disabled:opacity-40 disabled:hover:shadow-none transition-all duration-300 z-10"
              >
                <div className="relative z-10 flex items-center justify-center">
                  <Send className="w-5 h-5" />
                </div>
              </button>
            </div>
          </div>
          <div className="max-w-3xl mx-auto text-center mt-3 pointer-events-auto">
             <p className="text-[11px] text-slate-500 tracking-wide font-medium">
               AI Assistant may produce inaccurate info. Verify with official government resources.
             </p>
          </div>
        </div>
      </main>
    </div>
  );
}
